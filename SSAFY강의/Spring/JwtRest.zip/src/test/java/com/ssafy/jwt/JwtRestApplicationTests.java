package com.ssafy.jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
