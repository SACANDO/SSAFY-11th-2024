package com.ssafy.jwt.controller;

public class ArticleController {

}
