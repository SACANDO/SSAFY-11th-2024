package com.ssafy.jwt.model.service;

public interface AuthService {

}
