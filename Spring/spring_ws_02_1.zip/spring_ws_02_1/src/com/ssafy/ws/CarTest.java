package com.ssafy.ws;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class CarTest {
	public static void main(String[] args) throws GasException {
		ApplicationContext ac = new GenericXmlApplicationContext("applicationContext.xml");
		
		Driver driver = ac.getBean("driver",Driver.class);
		
		try {
		driver.doSomething();
		} catch(Exception e) {
			
		}
	}
}
