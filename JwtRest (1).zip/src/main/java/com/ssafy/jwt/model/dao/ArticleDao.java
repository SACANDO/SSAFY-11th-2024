package com.ssafy.jwt.model.dao;

public interface ArticleDao {

}
