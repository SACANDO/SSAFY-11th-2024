import java.util.Arrays;

public class 패턴매칭_KMP {
	//브루트포스 처럼 모두 비교하는 것이 아니라
	//부분문자열 중 접두사와 접미사가 일치하는 가장 긴 길이를 구해놓고 점푸한다.
	public static void main(String[] args) {
		String text = "ABABABACABAABABACACA";
		String pattern = "ABABACA";
		
		KMP(text, pattern);
	}
	
	//T : text
	//P : pattern
	private static void KMP(String T, String P) {
		//실패함수테이블 (부분문자열일치테이블)
		int[] pi = getPi(P);
//		System.out.println(Arrays.toString(pi));
		
		int j = 0; //패턴의 인덱스
		// i //본문의 인덱스
		for(int i = 0; i <T.length(); i++) {
			//달랐을 때 
			while(j>0 && T.charAt(i) != P.charAt(j)) {
				j = pi[j-1]; //점푸
			}
			
			//같았을 때
			if(T.charAt(i) == P.charAt(j)) {
				//패턴 찾았다!
				if(j == P.length()-1) {
					System.out.println((i-P.length()+1)+"에서 시작하면 패턴을 찾았습니다.");
					j = pi[j];
				}else {
					j++;
				}
			}
		}
		
	}

	private static int[] getPi(String P) {
		//부분문자열 중 접두사와 접미사가 일치하는 최대길이를 담을 배열
		int[] pi = new int[P.length()]; //0~i까지의 부분문자열을 뽑아내겠다.
		
		int j = 0; //여기까지는 같아요~~
		for(int i = 1; i < P.length(); i++) {
			//지금 두개의 포인트가 가리키는 값이 다르면
			while(j>0 && P.charAt(i) != P.charAt(j))
				j = pi[j-1];
			
			//지금 두개의 포인트가 가리키는 값이 같다면 저장
			if(P.charAt(i) == P.charAt(j)) {
				//i번쨰의 최대길이는 ++j한 값
				pi[i] = ++j;
			}
		}
		
		return pi;
	}
}
