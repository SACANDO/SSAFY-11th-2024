package com.ssafy.ws;

public interface Person {
	void doSomething() throws GasException;
}
