package com.ssafy.ws;

public class GasException extends Exception {
	public GasException() {
		System.out.println("!!!!!!!!!!기름부족!!!!!!!!!.");
	}
}
