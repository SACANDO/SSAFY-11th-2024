package com.ssafy.jwt.model.service;

public class ArticleServiceImpl {

}
